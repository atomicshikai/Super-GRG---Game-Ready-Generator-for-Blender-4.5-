bl_info = {
    "name": "Super GRG",
    "author": "Mortus, artbymortus@gmail.com",
    "version": (1, 2, 1),
    "blender": (4, 5, 0),
    "location": "3D View > N-Panel > Super GRG",
    "description": "Batch rename, material apply, LODs (global or per-object), and hierarchy-aware batch export with naming templates.",
    "category": "Object",
}

import bpy, os, re
from mathutils import Vector
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import StringProperty, IntProperty, BoolProperty, FloatProperty, EnumProperty, PointerProperty
import bpy.utils.previews

_preview = {}

def register_icons():
    global _preview
    pc = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    if os.path.isdir(icons_dir):
        for f in os.listdir(icons_dir):
            if f.lower().endswith(".png"):
                name = os.path.splitext(f)[0]
                pc.load(name, os.path.join(icons_dir, f), 'IMAGE')
    _preview["main"] = pc

def unregister_icons():
    global _preview
    for pc in _preview.values():
        bpy.utils.previews.remove(pc)
    _preview.clear()

def ic(name, fallback="BLENDER"):
    pc = _preview.get("main")
    if pc and name in pc:
        return {"icon_value": pc[name].icon_id}
    return {"icon": fallback}

def get_targets(context, scope, collection):
    if scope == 'SELECTION':
        return [o for o in context.selected_objects if o.type == 'MESH']
    if scope == 'COLLECTION' and collection:
        return [o for o in collection.all_objects if o.type == 'MESH']
    return []

def ensure_collection(name):
    col = bpy.data.collections.get(name)
    if not col:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col

def duplicate_object(obj):
    dup = obj.copy()
    dup.data = obj.data.copy()
    if obj.users_collection:
        obj.users_collection[0].objects.link(dup)
    else:
        bpy.context.scene.collection.objects.link(dup)
    return dup

def set_origin_center_of_mass(obj):
    prev_sel = bpy.context.selected_objects[:]
    prev_act = bpy.context.view_layer.objects.active
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
    bpy.ops.object.select_all(action='DESELECT')
    for o in prev_sel:
        if o and o.name in bpy.data.objects:
            o.select_set(True)
    bpy.context.view_layer.objects.active = prev_act

def safe_filename(name):
    bad = '<>:"/\\|?*'
    for ch in bad:
        name = name.replace(ch, '_')
    return name

def trailing_number(name, base):
    m = re.fullmatch(re.escape(base) + r'_(\d+)', name)
    if m: return int(m.group(1))
    m2 = re.fullmatch(re.escape(base) + r'(\d+)', name)
    if m2: return int(m2.group(1))
    m3 = re.search(r'(\d+)$', name)
    return int(m3.group(1)) if m3 else None

def find_collection_path(root, target, path=None):
    if path is None: path = []
    if root == target:
        return path + [root.name]
    for child in root.children:
        p = find_collection_path(child, target, path + [root.name])
        if p: return p
    return None

def get_first_collection(obj):
    return obj.users_collection[0] if obj.users_collection else None

def collection_path_from_scene(obj, explicit_root=None):
    col = get_first_collection(obj)
    if not col:
        return [], None
    root = explicit_root if explicit_root else bpy.context.scene.collection
    p = find_collection_path(root, col)
    if p:
        return p[1:], col.name
    else:
        return [col.name], col.name

class GRG_ObjectLODProps(PropertyGroup):
    use_override: BoolProperty(name="Use Override", default=False)
    lod_mode: EnumProperty(name="Mode", items=[('RATIO', "Percentage", ""), ('POLY', "Poly Budget", "")], default='RATIO')
    lod_levels: IntProperty(name="Levels", default=3, min=1, max=5)
    ratio_1: FloatProperty(name="LOD1 Ratio", default=0.8, min=0.0, max=1.0)
    ratio_2: FloatProperty(name="LOD2 Ratio", default=0.5, min=0.0, max=1.0)
    ratio_3: FloatProperty(name="LOD3 Ratio", default=0.25, min=0.0, max=1.0)
    ratio_4: FloatProperty(name="LOD4 Ratio", default=0.12, min=0.0, max=1.0)
    ratio_5: FloatProperty(name="LOD5 Ratio", default=0.06, min=0.0, max=1.0)
    poly_1: IntProperty(name="LOD1 Faces", default=2000, min=10)
    poly_2: IntProperty(name="LOD2 Faces", default=1000, min=10)
    poly_3: IntProperty(name="LOD3 Faces", default=500,  min=10)
    poly_4: IntProperty(name="LOD4 Faces", default=250,  min=10)
    poly_5: IntProperty(name="LOD5 Faces", default=125,  min=10)

class GRG_Props(PropertyGroup):
    base_name: StringProperty(name="Object Name", default="Rock")
    start_number: IntProperty(name="Start", default=1, min=0)
    padding: IntProperty(name="Padding", default=2, min=0, max=6)
    rename_mesh_data: BoolProperty(name="Rename Mesh Data", default=True)
    auto_number: BoolProperty(name="Auto Number from Existing", default=True)
    material: PointerProperty(name="Material", type=bpy.types.Material)
    mat_slot_mode: EnumProperty(name="Slot Mode", items=[('ONE', "Single Slot", ""), ('ALL', "All Slots", "")], default='ONE')
    mat_slot_index: IntProperty(name="Slot Index", default=0, min=0, max=128)
    lod_scope: EnumProperty(name="Source", items=[('SELECTION', "Selection", ""), ('COLLECTION', "Collection", "")], default='SELECTION')
    lod_collection: PointerProperty(name="Collection", type=bpy.types.Collection)
    lod_levels: IntProperty(name="Levels", default=3, min=1, max=5)
    lod_mode: EnumProperty(name="LOD Mode", items=[('RATIO', "Percentage", ""), ('POLY', "Poly Budget", "")], default='RATIO')
    lod_ratio_1: FloatProperty(name="LOD 1 Ratio", default=0.8, min=0.0, max=1.0)
    lod_ratio_2: FloatProperty(name="LOD 2 Ratio", default=0.5, min=0.0, max=1.0)
    lod_ratio_3: FloatProperty(name="LOD 3 Ratio", default=0.25, min=0.0, max=1.0)
    lod_ratio_4: FloatProperty(name="LOD 4 Ratio", default=0.12, min=0.0, max=1.0)
    lod_ratio_5: FloatProperty(name="LOD 5 Ratio", default=0.06, min=0.0, max=1.0)
    lod_poly_1: IntProperty(name="LOD 1 Faces", default=2000, min=10)
    lod_poly_2: IntProperty(name="LOD 2 Faces", default=1000, min=10)
    lod_poly_3: IntProperty(name="LOD 3 Faces", default=500, min=10)
    lod_poly_4: IntProperty(name="LOD 4 Faces", default=250, min=10)
    lod_poly_5: IntProperty(name="LOD 5 Faces", default=125, min=10)
    lod_out_mode: EnumProperty(name="Output Collections", items=[('SEPARATE', "Separate _LOD1/_LOD2/...", ""), ('SAME', "Single Collection", "")], default='SEPARATE')
    lod_single_collection_name: StringProperty(name="Collection Name", default="All_LODs")
    export_scope: EnumProperty(name="Source", items=[('SELECTION', "Selection", ""), ('COLLECTION', "Collection", "")], default='SELECTION')
    export_collection: PointerProperty(name="Collection", type=bpy.types.Collection)
    export_dir: StringProperty(name="Target Folder", subtype='DIR_PATH', default="")
    export_format: EnumProperty(name="Format", items=[('FBX', "FBX (.fbx)", ""), ('OBJ', "OBJ (.obj)", "")], default='FBX')
    pivot_mode: EnumProperty(name="Pivot", items=[('ORIGINAL', "Original", ""), ('CENTER', "Center of Mass", "")], default='ORIGINAL')
    apply_unit: BoolProperty(name="Apply Unit", default=False)
    apply_transform: BoolProperty(name="Apply Transform", default=True)
    reset_trs: BoolProperty(name="Reset to 0/0/0, 1/1/1", default=True)
    export_name_template: StringProperty(name="Naming Template", default="{object}")
    keep_hierarchy: BoolProperty(name="Keep Hierarchy", default=False)
    hierarchy_root: PointerProperty(name="Hierarchy Root", type=bpy.types.Collection)

class GRG_OT_SetPresetName(Operator):
    bl_idname = "grg.set_preset_name"
    bl_label = "Set Preset Name"
    name_value: StringProperty()
    def execute(self, context):
        context.scene.grg_props.base_name = self.name_value
        return {'FINISHED'}

class GRG_OT_Rename(Operator):
    bl_idname = "grg.rename"
    bl_label = "Generate Names"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        P = context.scene.grg_props
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        objs.sort(key=lambda o: o.name)
        if P.auto_number:
            max_found = -1
            for o in objs:
                n = trailing_number(o.name, P.base_name)
                if n is not None and n > max_found:
                    max_found = n
            start_num = (max_found + 1) if max_found >= 0 else P.start_number
        else:
            start_num = P.start_number
        num = start_num
        for o in objs:
            new_name = f"{P.base_name}_{str(num).zfill(P.padding)}"
            o.name = new_name
            if P.rename_mesh_data and o.data:
                o.data.name = new_name
            num += 1
        self.report({'INFO'}, f"Renamed {len(objs)} objects starting from {start_num}.")
        return {'FINISHED'}

class GRG_OT_ApplyMaterial(Operator):
    bl_idname = "grg.apply_material"
    bl_label = "Apply Material"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        P = context.scene.grg_props
        mat = P.material
        if not mat:
            self.report({'WARNING'}, "Please select a material.")
            return {'CANCELLED'}
        targets = [o for o in context.selected_objects if o.type == 'MESH']
        if not targets:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}
        for obj in targets:
            mats = obj.data.materials
            if P.mat_slot_mode == 'ALL':
                if not mats:
                    mats.append(mat)
                else:
                    for i in range(len(mats)):
                        mats[i] = mat
            else:
                idx = max(0, P.mat_slot_index)
                while len(mats) <= idx:
                    mats.append(None)
                mats[idx] = mat
        self.report({'INFO'}, f"Applied '{mat.name}' to {len(targets)} objects.")
        return {'FINISHED'}

def compute_levels_from_props(mode, levels, ratios, polys, src_faces):
    if mode == 'RATIO':
        vals = ratios[:levels]
        return [float(v) for v in vals]
    else:
        vals = polys[:levels]
        return [max(0.0, min(1.0, max(1, int(v)) / float(max(1, src_faces)))) for v in vals]

class GRG_OT_GenerateLODs(Operator):
    bl_idname = "grg.generate_lods"
    bl_label = "Generate LODs"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        P = context.scene.grg_props
        src_objs = get_targets(context, P.lod_scope, P.lod_collection)
        if not src_objs:
            self.report({'WARNING'}, "No source mesh objects found.")
            return {'CANCELLED'}
        global_ratios = [P.lod_ratio_1, P.lod_ratio_2, P.lod_ratio_3, P.lod_ratio_4, P.lod_ratio_5]
        global_polys  = [P.lod_poly_1,  P.lod_poly_2,  P.lod_poly_3,  P.lod_poly_4,  P.lod_poly_5]
        single_col = ensure_collection(P.lod_single_collection_name) if P.lod_out_mode == 'SAME' else None
        made = 0
        for src in src_objs:
            base = src.name
            lod0 = duplicate_object(src)
            lod0.name = f"{base}_LOD0"
            lod0.data.name = lod0.name
            if P.lod_out_mode == 'SEPARATE':
                col0 = ensure_collection("_LOD0")
                for c in lod0.users_collection:
                    c.objects.unlink(lod0)
                col0.objects.link(lod0)
            else:
                for c in lod0.users_collection:
                    c.objects.unlink(lod0)
                single_col.objects.link(lod0)
            src_faces = max(1, len(src.data.polygons))
            opl = src.grg_lod
            if opl.use_override:
                e_mode   = opl.lod_mode
                e_levels = opl.lod_levels
                e_ratios = [opl.ratio_1, opl.ratio_2, opl.ratio_3, opl.ratio_4, opl.ratio_5]
                e_polys  = [opl.poly_1,  opl.poly_2,  opl.poly_3,  opl.poly_4,  opl.poly_5]
            else:
                e_mode   = P.lod_mode
                e_levels = P.lod_levels
                e_ratios = global_ratios
                e_polys  = global_polys
            ratios_for_apply = compute_levels_from_props(e_mode, e_levels, e_ratios, e_polys, src_faces)
            for i, ratio in enumerate(ratios_for_apply, start=1):
                dup = duplicate_object(src)
                dup.name = f"{base}_LOD{i}"
                dup.data.name = dup.name
                mod = dup.modifiers.new(name=f"Decimate_LOD{i}", type='DECIMATE')
                mod.ratio = float(ratio)
                mod.use_collapse_triangulate = False
                prev_sel = bpy.context.selected_objects[:]
                prev_act = bpy.context.view_layer.objects.active
                bpy.ops.object.select_all(action='DESELECT')
                dup.select_set(True)
                bpy.context.view_layer.objects.active = dup
                try:
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                except Exception:
                    pass
                bpy.ops.object.select_all(action='DESELECT')
                for o in prev_sel:
                    if o and o.name in bpy.data.objects:
                        o.select_set(True)
                bpy.context.view_layer.objects.active = prev_act
                if P.lod_out_mode == 'SEPARATE':
                    col = ensure_collection(f"_LOD{i}")
                    for cu in dup.users_collection:
                        cu.objects.unlink(dup)
                    col.objects.link(dup)
                else:
                    for cu in dup.users_collection:
                        cu.objects.unlink(dup)
                    single_col.objects.link(dup)
                made += 1
        self.report({'INFO'}, f"Generated {made + len(src_objs)} LOD objects (including LOD0 copies).")
        return {'FINISHED'}

def render_export_name(obj, template):
    scene = bpy.context.scene
    col = get_first_collection(obj)
    col_name = col.name if col else ""
    path_list, _ = collection_path_from_scene(obj)
    collection_path = "/".join(path_list) if path_list else col_name
    tokens = {
        "object": obj.name,
        "collection": col_name,
        "collection_path": collection_path,
        "scene.frame_current": scene.frame_current,
    }
    out = template
    for k, v in tokens.items():
        out = out.replace("{" + k + "}", str(v))
    return safe_filename(out)

class GRG_OT_BatchExport(Operator):
    bl_idname = "grg.batch_export"
    bl_label = "Export"
    bl_options = {'REGISTER'}
    def execute(self, context):
        P = context.scene.grg_props
        src_objs = get_targets(context, P.export_scope, P.export_collection)
        if not src_objs:
            self.report({'WARNING'}, "No objects to export.")
            return {'CANCELLED'}
        export_dir = P.export_dir.strip()
        if not export_dir:
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            export_dir = os.path.join(desktop, "Export")
        export_dir = os.path.abspath(export_dir)
        os.makedirs(export_dir, exist_ok=True)
        temp_col = ensure_collection("_GRG_EXPORT_TEMP")
        exported = 0
        prev_sel = bpy.context.selected_objects[:]
        prev_act = bpy.context.view_layer.objects.active
        for src in src_objs:
            dup = src.copy()
            dup.data = src.data.copy()
            bpy.context.scene.collection.objects.link(dup)
            if P.pivot_mode == 'CENTER':
                set_origin_center_of_mass(dup)
            if P.reset_trs:
                dup.location = Vector((0.0, 0.0, 0.0))
                dup.rotation_euler = (0.0, 0.0, 0.0)
                dup.scale = (1.0, 1.0, 1.0)
            for col in dup.users_collection:
                col.objects.unlink(dup)
            temp_col.objects.link(dup)
            rel_dir = ""
            if P.keep_hierarchy:
                path_list, _leaf = collection_path_from_scene(src, explicit_root=P.hierarchy_root)
                if path_list:
                    rel_dir = os.path.join(*[safe_filename(p) for p in path_list])
            fname_core = render_export_name(src, P.export_name_template)
            fname = fname_core if fname_core else safe_filename(dup.name)
            out_dir = os.path.join(export_dir, rel_dir) if rel_dir else export_dir
            os.makedirs(out_dir, exist_ok=True)
            filepath = os.path.join(out_dir, fname)
            bpy.ops.object.select_all(action='DESELECT')
            dup.select_set(True)
            bpy.context.view_layer.objects.active = dup
            try:
                if P.export_format == 'FBX':
                    bpy.ops.export_scene.fbx(
                        filepath=filepath + ".fbx",
                        use_selection=True,
                        apply_unit_scale=P.apply_unit is False,
                        apply_scale_options='FBX_SCALE_ALL',
                        bake_space_transform=P.apply_transform,
                        object_types={'MESH'},
                        use_mesh_modifiers=True,
                        path_mode='AUTO',
                        add_leaf_bones=False,
                        use_custom_props=False,
                    )
                else:
                    bpy.ops.wm.obj_export(
                        filepath=filepath + ".obj",
                        export_selected_objects=True,
                        export_eval_mode='DAG_EVAL_VIEWPORT',
                        export_triangulated=False,
                        export_materials=True,
                        export_smooth_groups=False,
                        apply_modifiers=True,
                        forward_axis='NEGATIVE_Z',
                        up_axis='Y',
                    )
                exported += 1
            except Exception as e:
                self.report({'WARNING'}, f"Failed to export {dup.name}: {e}")
            finally:
                bpy.data.objects.remove(dup, do_unlink=True)
        if not temp_col.objects:
            try:
                bpy.context.scene.collection.children.unlink(temp_col)
                bpy.data.collections.remove(temp_col)
            except Exception:
                pass
        bpy.ops.object.select_all(action='DESELECT')
        for o in prev_sel:
            if o and o.name in bpy.data.objects:
                o.select_set(True)
        if prev_act and prev_act.name in bpy.data.objects:
            bpy.context.view_layer.objects.active = prev_act
        self.report({'INFO'}, f"Exported successfully: {exported} file(s).")
        return {'FINISHED'}

class GRG_PT_Main(Panel):
    bl_label = "Super GRG"
    bl_idname = "GRG_PT_Main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Super GRG"
    def draw(self, context):
        P = context.scene.grg_props
        layout = self.layout

        box = layout.box()
        box.label(text="Batch Rename", **ic("rename", "OUTLINER_DATA_FONT"))
        row = box.row(align=True)
        op = row.operator("grg.set_preset_name", text="Rock", **ic("preset_rock", "MESH_ICOSPHERE")); op.name_value = "Rock"
        op = row.operator("grg.set_preset_name", text="Tree", **ic("preset_tree", "OUTLINER_OB_CURVES")); op.name_value = "Tree"
        op = row.operator("grg.set_preset_name", text="House", **ic("preset_house", "HOME")); op.name_value = "House"
        row = box.row(align=True); row.prop(P, "base_name")
        row = box.row(align=True); row.prop(P, "start_number"); row.prop(P, "padding")
        box.prop(P, "auto_number")
        box.prop(P, "rename_mesh_data")
        box.operator("grg.rename", **ic("btn_rename", "SORTALPHA"))

        box = layout.box()
        box.label(text="Apply Material", **ic("material", "MATERIAL"))
        box.prop(P, "material")
        row = box.row(align=True)
        row.prop(P, "mat_slot_mode", expand=True)
        if P.mat_slot_mode == 'ONE':
            box.prop(P, "mat_slot_index")
        box.operator("grg.apply_material", **ic("btn_material", "CHECKMARK"))

        box = layout.box()
        box.label(text="Generate LODs (Global)", **ic("lod", "MOD_DECIM"))
        row = box.row(align=True)
        row.prop(P, "lod_scope", expand=True)
        if P.lod_scope == 'COLLECTION':
            box.prop(P, "lod_collection")
        box.prop(P, "lod_levels")
        box.prop(P, "lod_mode", expand=True)
        col = box.column(align=True)
        if P.lod_mode == 'RATIO':
            col.prop(P, "lod_ratio_1")
            if P.lod_levels >= 2: col.prop(P, "lod_ratio_2")
            if P.lod_levels >= 3: col.prop(P, "lod_ratio_3")
            if P.lod_levels >= 4: col.prop(P, "lod_ratio_4")
            if P.lod_levels >= 5: col.prop(P, "lod_ratio_5")
        else:
            col.prop(P, "lod_poly_1")
            if P.lod_levels >= 2: col.prop(P, "lod_poly_2")
            if P.lod_levels >= 3: col.prop(P, "lod_poly_3")
            if P.lod_levels >= 4: col.prop(P, "lod_poly_4")
            if P.lod_levels >= 5: col.prop(P, "lod_poly_5")
        box.prop(P, "lod_out_mode", expand=True)
        if P.lod_out_mode == 'SAME':
            box.prop(P, "lod_single_collection_name")
        box.operator("grg.generate_lods", **ic("btn_lod", "OUTLINER_OB_MESH"))

        box = layout.box()
        box.label(text="Batch Export", **ic("export", "EXPORT"))
        row = box.row(align=True)
        row.prop(P, "export_scope", expand=True)
        if P.export_scope == 'COLLECTION':
            box.prop(P, "export_collection")
        box.prop(P, "export_dir")
        row = box.row(align=True); row.prop(P, "export_format", expand=True)
        row = box.row(align=True); row.prop(P, "pivot_mode", expand=True)
        row = box.row(align=True); row.prop(P, "apply_unit"); row.prop(P, "apply_transform")
        box.prop(P, "reset_trs")
        box.prop(P, "keep_hierarchy")
        if P.keep_hierarchy:
            box.prop(P, "hierarchy_root")
        box.prop(P, "export_name_template")
        box.operator("grg.batch_export", **ic("btn_export", "FILE_TICK"))

class GRG_PT_ObjectLOD(Panel):
    bl_label = "Super GRG: Per-Object LOD"
    bl_idname = "GRG_PT_ObjectLOD"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"
    def draw(self, context):
        obj = context.object
        if not obj: return
        P = obj.grg_lod
        layout = self.layout
        layout.prop(P, "use_override")
        col = layout.column()
        col.enabled = P.use_override
        col.prop(P, "lod_mode", expand=True)
        col.prop(P, "lod_levels")
        if P.lod_mode == 'RATIO':
            col.prop(P, "ratio_1")
            if P.lod_levels >= 2: col.prop(P, "ratio_2")
            if P.lod_levels >= 3: col.prop(P, "ratio_3")
            if P.lod_levels >= 4: col.prop(P, "ratio_4")
            if P.lod_levels >= 5: col.prop(P, "ratio_5")
        else:
            col.prop(P, "poly_1")
            if P.lod_levels >= 2: col.prop(P, "poly_2")
            if P.lod_levels >= 3: col.prop(P, "poly_3")
            if P.lod_levels >= 4: col.prop(P, "poly_4")
            if P.lod_levels >= 5: col.prop(P, "poly_5")

classes = (
    GRG_ObjectLODProps,
    GRG_Props,
    GRG_OT_SetPresetName,
    GRG_OT_Rename,
    GRG_OT_ApplyMaterial,
    GRG_OT_GenerateLODs,
    GRG_OT_BatchExport,
    GRG_PT_Main,
    GRG_PT_ObjectLOD,
)

def register():
    register_icons()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.grg_props = PointerProperty(type=GRG_Props)
    bpy.types.Object.grg_lod = PointerProperty(type=GRG_ObjectLODProps)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.grg_props
    del bpy.types.Object.grg_lod
    unregister_icons()

if __name__ == "__main__":
    register()
